from django.db import models
from decimal import Decimal
from django.db.models import Count, Max


class RealEstateListingManager(models.Manager):

    def by_property_type(self, property_type: str):
        return self.filter(property_type=property_type)

    def in_price_range(self, min_price: Decimal, max_price: Decimal):
        return self.filter(price__range=[min_price, max_price])

    def with_bedrooms(self, bedrooms_count: int):
        return self.filter(bedrooms=bedrooms_count)

    def popular_locations(self):
        return (
            self.values("location")
            .annotate(visit_count=Count("location"))
            .order_by("-visit_count", "location")[:2]
        )
