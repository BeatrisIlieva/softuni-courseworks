//DO NOT CHANGE
export interface Room {
    readonly roomNumber: 'A01' | 'A02' | 'A03' | 'B01' | 'B02' | 'B03';
    readonly totalPrice: number;
    readonly cancellationPrice: number;
}