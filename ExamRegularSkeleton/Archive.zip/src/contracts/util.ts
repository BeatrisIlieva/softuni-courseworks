//DO NOT CHANGE
export enum WinterMonth {
    December = 'December',
    January = 'January',
    February = 'February',
    March = 'March'
};

export enum SummerMonth {
    June = 'June',
    July = 'July',
    August = 'August',
    September = 'September'
};

