import { RoomNumber } from './types';

export const roomNumbers: RoomNumber[] = ['A01', 'A02', 'A03', 'B01', 'B02', 'B03'];
