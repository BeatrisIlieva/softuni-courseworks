function solve() {
    const baseUrl = 'http://localhost:3030/jsonstore/bus/schedule/';
    const infoElement = document.querySelector('#info .info');
    const departInputElement = document.getElementById('depart');
    const arriveInputElement = document.getElementById('arrive');
    let currentStopId = 'depot';
    let currentStopName = '';

    function depart() {
        departInputElement.disabled = true;
        arriveInputElement.disabled = false;

        fetch(`${baseUrl}/${currentStopId}`)
            .then(response => response.json())
            .then(result => {
                currentStopId = result.next;
                currentStopName = result.name;
                infoElement.textContent = `Next stop ${currentStopName}`;
            })
            .catch(error => console.log(error));
    }

    async function arrive() {
        arriveInputElement.disabled = true;
        departInputElement.disabled = false;

        infoElement.textContent = `Arriving at ${currentStopName}`;
    }

    return {
        depart,
        arrive,
    };
}

let result = solve();
